<?php


class Destination
{
    public $address;
    public $location;
}
