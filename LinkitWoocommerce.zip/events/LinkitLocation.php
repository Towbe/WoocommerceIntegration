<?php


class LinkitLocation
{
    public $lat;
    public $lng;

    /**
     * LinkitLocation constructor.
     * @param $lat
     * @param $lng
     */
    public function __construct()
    {
        $this->lat = 0;
        $this->lng = 0;
    }
}
