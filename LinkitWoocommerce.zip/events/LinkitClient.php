<?php


class LinkitClient
{
    public $name;
    public $reference_id;
    public $phone_number;
}
